export const performers = [
		"Michael Jackson", 
		"Frank Sinatra",
		"Calvin Harris",
		"Zhu",
		"Arctic Monkeys"
	]

export const genres = [
	"Рок",
	"Хип-хоп",
	"Поп-музыка",
	"Техно",
	"Инди"
]

